#!/usr/bin/env python3
"""Генерирует supabase/seed.sql из scripts/characters.txt."""
from pathlib import Path

root = Path(__file__).resolve().parent.parent
rows = []
for line in (root / "scripts" / "characters.txt").read_text(encoding="utf-8").splitlines():
    line = line.strip()
    if not line or line.startswith("#"):
        continue
    slug, name, g, element, region = line.split("|")
    gender = {"f": "female", "m": "male"}[g]
    rows.append((slug, name, gender, element, region))

values = ",\n".join(
    "  ('{}', '{}', '{}', '{}', '{}', {})".format(
        s.replace("'", "''"), n.replace("'", "''"), g, e, r, i
    )
    for i, (s, n, g, e, r) in enumerate(rows, start=1)
)

sql = f"""-- Начальный каталог персонажей Genshin Impact ({len(rows)} шт.)
-- Выполнять ПОСЛЕ schema.sql. Повторный запуск безопасен: существующие персонажи
-- (и их статусы/картинки) не затрагиваются.
insert into public.characters (slug, name, gender, element, region, sort_order)
values
{values}
on conflict (slug) do nothing;
"""
(root / "supabase" / "seed.sql").write_text(sql, encoding="utf-8")
print(f"seed.sql: {len(rows)} персонажей")

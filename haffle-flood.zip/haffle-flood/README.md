# HAFFLE FLOOD

Сайт-визитка Telegram-флуда по Genshin Impact: главная, каталог персонажей со статусами и фильтрами, защищённая админ-панель.

**Стек:** Next.js 15 (App Router) · React 19 · TypeScript · Tailwind CSS · Supabase (Postgres, Auth, Storage) · Lucide.

## Структура проекта

```
haffle-flood/
├─ supabase/
│  ├─ schema.sql            ← таблицы, RLS-политики, bucket для картинок
│  └─ seed.sql              ← 109 персонажей (сгенерирован из scripts/characters.txt)
├─ scripts/
│  ├─ characters.txt        ← исходный список персонажей
│  └─ generate_seed.py      ← python3 scripts/generate_seed.py → seed.sql
├─ src/
│  ├─ middleware.ts         ← обновление сессии, /admin закрыт для гостей
│  ├─ lib/                  ← supabase-клиент, проверка админа, загрузка файлов, типы
│  ├─ app/
│  │  ├─ layout.tsx, globals.css
│  │  ├─ page.tsx           ← главная
│  │  ├─ characters/page.tsx← каталог
│  │  ├─ actions/auth.ts    ← вход / выход (server actions)
│  │  └─ admin/             ← страница и server actions админки
│  └─ components/           ← Navbar, карточки, фильтры, админ-разделы
├─ .env.example
└─ README.md
```

## 1. Установка

Нужен Node.js 20+.

```bash
npm install
```

Файл `.env.local` уже заполнен вашими URL и publishable-ключом проекта Supabase. Для другого проекта скопируйте `.env.example` в `.env.local` и подставьте свои значения (Supabase → Project Settings → API).

> Используйте только **publishable** (бывший anon) ключ. Secret / service_role ключ сайту не нужен — не добавляйте его никуда.

## 2. Подключение Supabase

1. Откройте проект → **SQL Editor** → New query.
2. Вставьте содержимое `supabase/schema.sql` → **Run**.
3. Новый запрос → вставьте `supabase/seed.sql` → **Run** (загрузит всех персонажей).
4. Проверьте: **Storage** должен содержать публичный bucket `media`, а **Table Editor** — таблицы `characters`, `staff`, `site_settings`, `site_admins`.

## 3. Первый администратор

1. Supabase → **Authentication → Users → Add user → Create new user**: укажите e-mail и пароль, отметьте **Auto Confirm User**. E-mail — это ваш «логин» для входа на сайте. Пароль Supabase хранит в виде bcrypt-хеша.
2. Откройте **SQL Editor** и выполните (подставьте свой e-mail):

```sql
insert into public.site_admins (user_id)
select id from auth.users where email = 'ВАШ_EMAIL@example.com';
```

3. Рекомендуется выключить самостоятельную регистрацию: **Authentication → Sign In / Providers → Allow new users to sign up = off**. Даже если кто-то зарегистрируется, админом он не станет (права даёт только таблица `site_admins`), но лишние аккаунты не нужны.

## 4. Запуск

```bash
npm run dev      # http://localhost:3000
```

Нажмите шестерёнку в углу навигации → войдите → откроется панель управления.

Проверка перед публикацией: `npm run typecheck && npm run build`.

## 5. Как пользоваться админ-панелью

| Раздел | Что можно |
|---|---|
| Главная | название флуда, подзаголовок, две декоративные PNG слева/справа от заголовка |
| Персонажи | поиск, клик по карточке → имя, статус, PNG (предпросмотр, замена, удаление), пол/стихия/регион, удаление; «Добавить персонажа» для новинок |
| Администрация | добавить / изменить / удалить: аватар, никнейм, должность |
| Настройки | ссылка Telegram, количество участников, описание каталога |

Новый персонаж Genshin вышел — нажмите «Добавить персонажа» в разделе «Персонажи» и заполните форму.

## 6. Безопасность

- Вход выполняется **на сервере** (`signInWithPassword` в Server Action); сессия хранится в httpOnly-cookie, токен проверяется на сервере Supabase (`getUser()`), а не просто читается из cookie.
- Каждое изменение (Server Action) заново проверяет, что пользователь есть в `site_admins`.
- Дополнительный уровень — **RLS в самой базе**: читать могут все, писать — только `is_admin()`. Даже зная ключ, посторонний ничего не изменит.
- Загрузка файлов: проверка размера (≤ 3 МБ) и реального формата по сигнатуре байтов (PNG для персонажей и декора; PNG/JPEG/WebP для аватаров), уникальные имена, ограничения на уровне bucket.
- В коде нет паролей и секретных ключей.

## 7. Публикация (Vercel)

1. Загрузите проект в GitHub (файл `.env.local` в репозиторий не попадёт — он в `.gitignore`).
2. [vercel.com](https://vercel.com) → **Add New → Project** → выберите репозиторий.
3. В **Environment Variables** добавьте:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
4. **Deploy**. Сайт будет доступен по адресу вида `haffle-flood.vercel.app` (можно подключить свой домен).
5. Supabase → **Authentication → URL Configuration** → в *Site URL* укажите адрес сайта.

## Примечания

- Список персонажей составлен по моим знаниям на момент создания. Самые свежие персонажи (6.x: например Далия, Варка, Дурин) и их стихии/регионы стоит сверить с игрой — все поля редактируются в админке. Отсутствующих персонажей добавляйте кнопкой «Добавить персонажа».
- У Путешественника (Итэр / Люмин) стихия меняется в игре; в каталоге указана одна стихия — её можно поменять в админке.

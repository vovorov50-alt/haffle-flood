/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: { ignoreDuringBuilds: true },
  experimental: {
    // загрузка PNG идёт через Server Actions
    serverActions: { bodySizeLimit: "6mb" },
  },
};

export default nextConfig;

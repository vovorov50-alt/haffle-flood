import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: { DEFAULT: "#0B1F4B", soft: "#1B2F5E" },
        brand: {
          50: "#F2F7FF",
          100: "#E1ECFF",
          200: "#C3D9FF",
          300: "#94BAFF",
          400: "#5E92FF",
          500: "#2F6BFF",
          600: "#1F57E6",
          700: "#1744B8",
        },
        steel: "#5F7090",
        mist: "#F5F8FC",
      },
      fontFamily: {
        sans: ["var(--font-sans)", "system-ui", "sans-serif"],
      },
      boxShadow: {
        soft: "0 1px 2px rgba(11,31,75,0.04), 0 8px 24px -12px rgba(11,31,75,0.12)",
        lift: "0 2px 4px rgba(11,31,75,0.05), 0 18px 36px -14px rgba(47,107,255,0.28)",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(14px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        float: {
          "0%,100%": { transform: "translateY(0)" },
          "50%": { transform: "translateY(-8px)" },
        },
        pop: {
          "0%": { opacity: "0", transform: "scale(.96)" },
          "100%": { opacity: "1", transform: "scale(1)" },
        },
      },
      animation: {
        "fade-up": "fade-up .6s cubic-bezier(.2,.7,.2,1) both",
        float: "float 7s ease-in-out infinite",
        pop: "pop .18s ease-out both",
      },
    },
  },
  plugins: [],
};

export default config;

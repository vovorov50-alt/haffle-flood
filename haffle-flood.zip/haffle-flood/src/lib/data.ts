import { createClient } from "@/lib/supabase/server";
import { mediaUrl } from "@/lib/media";
import type { Character, CharacterView, Settings, StaffMember, StaffView } from "@/lib/types";

export const DEFAULT_SETTINGS: Settings = {
  id: 1,
  site_title: "Haffle flood",
  tagline: "Telegram-флуд по Genshin Impact.",
  members_count: 0,
  telegram_url: "",
  catalog_blurb: "Все персонажи Genshin Impact в одном месте.",
  hero_left_path: null,
  hero_right_path: null,
};

export async function getSettings(): Promise<Settings> {
  const supabase = await createClient();
  const { data } = await supabase.from("site_settings").select("*").eq("id", 1).maybeSingle();
  return { ...DEFAULT_SETTINGS, ...(data ?? {}) } as Settings;
}

export async function getCharacters(): Promise<CharacterView[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("characters")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("name", { ascending: true });
  return ((data ?? []) as Character[]).map((c) => ({ ...c, imageUrl: mediaUrl(c.image_path) }));
}

export async function getStaff(): Promise<StaffView[]> {
  const supabase = await createClient();
  const { data } = await supabase
    .from("staff")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: true });
  return ((data ?? []) as StaffMember[]).map((s) => ({ ...s, avatarUrl: mediaUrl(s.avatar_path) }));
}

import { createClient } from "@/lib/supabase/server";

/**
 * Возвращает контекст администратора или null.
 * Проверка идёт на сервере: токен валидируется в Supabase Auth (getUser),
 * затем пользователь должен присутствовать в таблице site_admins.
 */
export async function getAdminContext() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  if (!user) return null;

  const { data } = await supabase
    .from("site_admins")
    .select("user_id")
    .eq("user_id", user.id)
    .maybeSingle();
  if (!data) return null;

  return { supabase, user };
}

export type AdminContext = NonNullable<Awaited<ReturnType<typeof getAdminContext>>>;

import type { SupabaseClient } from "@supabase/supabase-js";

export const MAX_IMAGE_BYTES = 3 * 1024 * 1024;
const BUCKET = "media";

type Kind = "png" | "jpeg" | "webp";

/** Определяем реальный тип по "магическим байтам", а не по расширению/заголовку. */
function sniff(buf: Uint8Array): Kind | null {
  const eq = (offset: number, bytes: number[]) => bytes.every((b, i) => buf[offset + i] === b);
  if (buf.length > 12 && eq(0, [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a])) return "png";
  if (buf.length > 12 && eq(0, [0xff, 0xd8, 0xff])) return "jpeg";
  if (buf.length > 12 && eq(0, [0x52, 0x49, 0x46, 0x46]) && eq(8, [0x57, 0x45, 0x42, 0x50])) return "webp";
  return null;
}

const MIME: Record<Kind, string> = { png: "image/png", jpeg: "image/jpeg", webp: "image/webp" };
const EXT: Record<Kind, string> = { png: "png", jpeg: "jpg", webp: "webp" };

/** Достаёт файл из FormData, если он действительно выбран. */
export function pickFile(formData: FormData, field: string): File | null {
  const v = formData.get(field);
  return v instanceof File && v.size > 0 ? v : null;
}

/** Проверяет и загружает изображение. Возвращает путь в хранилище либо текст ошибки. */
export async function uploadImage(
  supabase: SupabaseClient,
  file: File,
  folder: string,
  opts: { pngOnly: boolean },
): Promise<{ path: string } | { error: string }> {
  if (file.size > MAX_IMAGE_BYTES) return { error: "Файл слишком большой (максимум 3 МБ)" };

  const bytes = new Uint8Array(await file.arrayBuffer());
  const kind = sniff(bytes);
  if (!kind) return { error: "Допустимы только изображения PNG, JPEG или WebP" };
  if (opts.pngOnly && kind !== "png") return { error: "Нужен файл в формате PNG" };

  const path = `${folder}/${crypto.randomUUID()}.${EXT[kind]}`;
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, bytes, { contentType: MIME[kind], cacheControl: "31536000", upsert: false });
  if (error) return { error: `Не удалось загрузить файл: ${error.message}` };

  return { path };
}

export async function removeImage(supabase: SupabaseClient, path: string | null | undefined) {
  if (!path) return;
  await supabase.storage.from(BUCKET).remove([path]);
}

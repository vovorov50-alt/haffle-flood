const TELEGRAM_HOSTS = new Set(['t.me', 'telegram.me', 'telegram.dog']);

/** Разрешаем только https-ссылки на Telegram (защита от javascript: и чужих доменов). */
export function isTelegramUrl(value: string): boolean {
  try {
    const url = new URL(value);
    return (
      url.protocol === 'https:' &&
      TELEGRAM_HOSTS.has(url.hostname.toLowerCase()) &&
      url.pathname.length > 1
    );
  } catch {
    return false;
  }
}

/** Русское склонение: plural(1, ["участник","участника","участников"]) */
export function plural(n: number, forms: [string, string, string]): string {
  const a = Math.abs(n) % 100;
  const b = a % 10;
  if (a > 10 && a < 20) return forms[2];
  if (b > 1 && b < 5) return forms[1];
  if (b === 1) return forms[0];
  return forms[2];
}

export function normalize(s: string): string {
  return s.toLowerCase().replace(/ё/g, "е").trim();
}

export function initials(s: string): string {
  return (s.trim()[0] ?? "?").toUpperCase();
}

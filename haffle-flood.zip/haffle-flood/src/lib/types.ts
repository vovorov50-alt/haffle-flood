export type Status = "free" | "busy" | "reserved";
export type Gender = "female" | "male";
export type Element = "pyro" | "hydro" | "anemo" | "electro" | "dendro" | "cryo" | "geo";
export type Region =
  | "mondstadt"
  | "liyue"
  | "inazuma"
  | "sumeru"
  | "fontaine"
  | "natlan"
  | "nodkrai"
  | "snezhnaya"
  | "other";

export interface Settings {
  id: number;
  site_title: string;
  tagline: string;
  members_count: number;
  telegram_url: string;
  catalog_blurb: string;
  hero_left_path: string | null;
  hero_right_path: string | null;
}

export interface Character {
  id: string;
  slug: string;
  name: string;
  gender: Gender;
  element: Element;
  region: Region;
  status: Status;
  image_path: string | null;
  sort_order: number;
}

/** Персонаж с готовой публичной ссылкой на картинку (для клиентских компонентов). */
export type CharacterView = Character & { imageUrl: string | null };

export interface StaffMember {
  id: string;
  nickname: string;
  role: string;
  avatar_path: string | null;
  sort_order: number;
}

export type StaffView = StaffMember & { avatarUrl: string | null };

export type ActionResult = { ok: true } | { ok: false; error: string };

import type { Element, Gender, Region, Status } from "./types";

export const STATUS_META: Record<Status, { label: string; dot: string; soft: string }> = {
  free: { label: "Свободен", dot: "bg-emerald-500", soft: "bg-emerald-50 text-emerald-700" },
  busy: { label: "Занят", dot: "bg-red-500", soft: "bg-red-50 text-red-700" },
  reserved: { label: "Бронь", dot: "bg-amber-400", soft: "bg-amber-50 text-amber-700" },
};
export const STATUSES = Object.keys(STATUS_META) as Status[];

export const GENDER_LABELS: Record<Gender, string> = { female: "Женский", male: "Мужской" };
export const GENDERS = Object.keys(GENDER_LABELS) as Gender[];

export const ELEMENT_LABELS: Record<Element, string> = {
  pyro: "Пиро",
  hydro: "Гидро",
  anemo: "Анемо",
  electro: "Электро",
  dendro: "Дендро",
  cryo: "Крио",
  geo: "Гео",
};
export const ELEMENTS = Object.keys(ELEMENT_LABELS) as Element[];

export const REGION_LABELS: Record<Region, string> = {
  mondstadt: "Мондштадт",
  liyue: "Ли Юэ",
  inazuma: "Инадзума",
  sumeru: "Сумеру",
  fontaine: "Фонтейн",
  natlan: "Натлан",
  nodkrai: "Нод-Край",
  snezhnaya: "Снежная",
  other: "Другое",
};
export const REGIONS = Object.keys(REGION_LABELS) as Region[];

export const ROLE_OPTIONS = ["Владелец", "Администратор", "Модератор"];

export const IMAGE_MAX_MB = 3;

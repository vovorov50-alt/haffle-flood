"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useState } from "react";
import { Settings } from "lucide-react";
import { LoginModal } from "@/components/LoginModal";

const LINKS = [
  { href: "/", label: "Главная" },
  { href: "/characters", label: "Персонажи" },
];

export function Navbar({ title, isAdmin }: { title: string; isAdmin: boolean }) {
  const pathname = usePathname();
  const [loginOpen, setLoginOpen] = useState(false);

  const gearClass =
    "ml-1 grid h-9 w-9 place-items-center rounded-xl text-steel transition hover:bg-brand-50 hover:text-brand-600";

  return (
    <header className="sticky top-0 z-40 border-b border-brand-100/80 bg-white/80 backdrop-blur-md">
      <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-2 px-4 sm:px-6">
        <Link href="/" className="flex min-w-0 items-center gap-2.5">
          <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-gradient-to-br from-brand-400 to-brand-600 text-sm font-extrabold text-white shadow-sm">
            H
          </span>
          <span className="truncate text-[15px] font-extrabold tracking-tight text-ink">{title}</span>
        </Link>

        <nav className="flex shrink-0 items-center gap-0.5">
          {LINKS.map((l) => {
            const active = l.href === "/" ? pathname === "/" : pathname.startsWith(l.href);
            return (
              <Link
                key={l.href}
                href={l.href}
                aria-current={active ? "page" : undefined}
                className={`rounded-xl px-3 py-2 text-sm font-semibold transition ${
                  active ? "bg-brand-50 text-brand-600" : "text-steel hover:bg-brand-50/70 hover:text-ink"
                }`}
              >
                {l.label}
              </Link>
            );
          })}

          {isAdmin ? (
            <Link href="/admin" aria-label="Панель управления" title="Панель управления" className={gearClass}>
              <Settings className="h-[18px] w-[18px]" />
            </Link>
          ) : (
            <button
              type="button"
              aria-label="Вход для администратора"
              title="Вход для администратора"
              className={gearClass}
              onClick={() => setLoginOpen(true)}
            >
              <Settings className="h-[18px] w-[18px]" />
            </button>
          )}
        </nav>
      </div>

      {!isAdmin && <LoginModal open={loginOpen} onClose={() => setLoginOpen(false)} />}
    </header>
  );
}

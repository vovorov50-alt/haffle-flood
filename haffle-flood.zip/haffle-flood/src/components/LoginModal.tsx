"use client";

import { useActionState } from "react";
import { Loader2, Lock } from "lucide-react";
import { Modal } from "@/components/ui/Modal";
import { login, type LoginState } from "@/app/actions/auth";

export function LoginModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [state, formAction, pending] = useActionState<LoginState, FormData>(login, undefined);

  return (
    <Modal open={open} onClose={onClose} title="Вход для администратора">
      <form action={formAction} className="space-y-4">
        <div>
          <label className="label" htmlFor="login-email">
            Логин (e-mail)
          </label>
          <input
            id="login-email"
            name="email"
            type="email"
            autoComplete="username"
            required
            className="input"
            placeholder="admin@example.com"
          />
        </div>
        <div>
          <label className="label" htmlFor="login-password">
            Пароль
          </label>
          <input
            id="login-password"
            name="password"
            type="password"
            autoComplete="current-password"
            required
            className="input"
            placeholder="••••••••"
          />
        </div>

        {state?.error && (
          <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm text-red-700">
            {state.error}
          </p>
        )}

        <button type="submit" className="btn-primary w-full" disabled={pending}>
          {pending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
          Войти
        </button>
      </form>
    </Modal>
  );
}

"use client";

import { Loader2 } from "lucide-react";
import { removeHeroImage, setHeroImage, updateSettings } from "@/app/admin/actions";
import { Feedback } from "@/components/admin/Feedback";
import { ImagePicker } from "@/components/admin/ImagePicker";
import { useRun } from "@/components/admin/useRun";
import { mediaUrl } from "@/lib/media";
import type { Settings } from "@/lib/types";

function HeroImageForm({ side, title, path }: { side: "left" | "right"; title: string; path: string | null }) {
  const { run, pending, error, saved } = useRun();
  const url = mediaUrl(path);

  return (
    <form
      key={path ?? "empty"}
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        fd.set("side", side);
        run(() => setHeroImage(fd));
      }}
      className="space-y-4"
    >
      <p className="text-sm font-bold text-ink">{title}</p>
      <ImagePicker currentUrl={url} shape="wide" allowRemove={false} hint="PNG с прозрачным фоном, до 3 МБ" />
      <div className="flex flex-wrap items-center gap-2">
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending && <Loader2 className="h-4 w-4 animate-spin" />}
          Сохранить
        </button>
        {url && (
          <button type="button" className="btn-danger" disabled={pending} onClick={() => run(() => removeHeroImage(side))}>
            Удалить изображение
          </button>
        )}
        <Feedback error={error} saved={saved} />
      </div>
    </form>
  );
}

export function HomeSection({ settings }: { settings: Settings }) {
  const { run, pending, error, saved } = useRun();

  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <section className="card p-6 lg:col-span-2">
        <h2 className="text-lg font-extrabold text-ink">Заголовок главной страницы</h2>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            run(() => updateSettings(fd));
          }}
          className="mt-4 space-y-4"
        >
          <div>
            <label className="label" htmlFor="site_title">
              Название флуда
            </label>
            <input id="site_title" name="site_title" defaultValue={settings.site_title} maxLength={60} required className="input" />
          </div>
          <div>
            <label className="label" htmlFor="tagline">
              Подзаголовок под названием
            </label>
            <textarea id="tagline" name="tagline" defaultValue={settings.tagline} maxLength={300} rows={3} className="input resize-y" />
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <button type="submit" className="btn-primary" disabled={pending}>
              {pending && <Loader2 className="h-4 w-4 animate-spin" />}
              Сохранить
            </button>
            <Feedback error={error} saved={saved} />
          </div>
        </form>
      </section>

      <section className="card p-6">
        <h2 className="mb-1 text-lg font-extrabold text-ink">Декоративные персонажи</h2>
        <p className="mb-5 text-sm text-steel">Две PNG-картинки по бокам от заголовка на главной.</p>
        <HeroImageForm side="left" title="Слева от заголовка" path={settings.hero_left_path} />
      </section>

      <section className="card p-6">
        <HeroImageForm side="right" title="Справа от заголовка" path={settings.hero_right_path} />
      </section>
    </div>
  );
}

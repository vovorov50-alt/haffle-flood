"use client";

import { useCallback, useEffect, useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import type { ActionResult } from "@/lib/types";

/** Запуск server action: pending, ошибка, флаг «сохранено», обновление страницы. */
export function useRun() {
  const router = useRouter();
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => void (timer.current && clearTimeout(timer.current)), []);

  const run = useCallback(
    (fn: () => Promise<ActionResult>, onOk?: () => void) => {
      start(async () => {
        setError(null);
        setSaved(false);
        let res: ActionResult;
        try {
          res = await fn();
        } catch {
          res = { ok: false, error: "Ошибка соединения. Попробуйте ещё раз." };
        }
        if (!res.ok) {
          setError(res.error);
          return;
        }
        setSaved(true);
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(() => setSaved(false), 2500);
        router.refresh();
        onOk?.();
      });
    },
    [router],
  );

  return { run, pending, error, setError, saved };
}

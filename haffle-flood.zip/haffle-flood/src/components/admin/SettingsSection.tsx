"use client";

import { Loader2 } from "lucide-react";
import { updateSettings } from "@/app/admin/actions";
import { Feedback } from "@/components/admin/Feedback";
import { useRun } from "@/components/admin/useRun";
import type { Settings } from "@/lib/types";

export function SettingsSection({ settings }: { settings: Settings }) {
  const { run, pending, error, saved } = useRun();

  return (
    <section className="card max-w-2xl p-6">
      <h2 className="text-lg font-extrabold text-ink">Настройки сайта</h2>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          run(() => updateSettings(fd));
        }}
        className="mt-5 space-y-5"
      >
        <div>
          <label className="label" htmlFor="telegram_url">
            Ссылка-приглашение в Telegram
          </label>
          <input
            id="telegram_url"
            name="telegram_url"
            type="url"
            defaultValue={settings.telegram_url}
            placeholder="https://t.me/+xxxxxxxxxxxx"
            className="input"
          />
          <p className="mt-1.5 text-xs text-steel">На неё ведёт кнопка «Вступить» на главной странице.</p>
        </div>

        <div>
          <label className="label" htmlFor="members_count">
            Количество участников флуда
          </label>
          <input
            id="members_count"
            name="members_count"
            type="number"
            min={0}
            step={1}
            inputMode="numeric"
            defaultValue={settings.members_count}
            required
            className="input max-w-[12rem]"
          />
          <p className="mt-1.5 text-xs text-steel">Обновляется вручную — сайт сам ничего не считает.</p>
        </div>

        <div>
          <label className="label" htmlFor="catalog_blurb">
            Описание каталога персонажей
          </label>
          <textarea
            id="catalog_blurb"
            name="catalog_blurb"
            rows={3}
            maxLength={400}
            defaultValue={settings.catalog_blurb}
            className="input resize-y"
          />
          <p className="mt-1.5 text-xs text-steel">Показывается на главной и над каталогом.</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button type="submit" className="btn-primary" disabled={pending}>
            {pending && <Loader2 className="h-4 w-4 animate-spin" />}
            Сохранить
          </button>
          <Feedback error={error} saved={saved} />
        </div>
      </form>
    </section>
  );
}

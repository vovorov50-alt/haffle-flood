"use client";

import { useState } from "react";
import { Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { deleteStaff, saveStaff } from "@/app/admin/actions";
import { Feedback } from "@/components/admin/Feedback";
import { ImagePicker } from "@/components/admin/ImagePicker";
import { useRun } from "@/components/admin/useRun";
import { ConfirmDialog, Modal } from "@/components/ui/Modal";
import { Select } from "@/components/ui/Select";
import { ROLE_OPTIONS } from "@/lib/constants";
import { initials } from "@/lib/format";
import type { StaffView } from "@/lib/types";

function StaffEditor({ member, onClose }: { member: StaffView | null; onClose: () => void }) {
  const { run, pending, error } = useRun();
  const roles = member && !ROLE_OPTIONS.includes(member.role) ? [...ROLE_OPTIONS, member.role] : ROLE_OPTIONS;

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        const fd = new FormData(e.currentTarget);
        run(() => saveStaff(fd), onClose);
      }}
      className="space-y-4"
    >
      <input type="hidden" name="id" value={member?.id ?? ""} />
      <ImagePicker currentUrl={member?.avatarUrl} shape="circle" pngOnly={false} hint="Аватар: PNG, JPEG или WebP, до 3 МБ" />

      <div>
        <label className="label" htmlFor="s-nick">
          Никнейм
        </label>
        <input id="s-nick" name="nickname" defaultValue={member?.nickname ?? ""} maxLength={40} required className="input" />
      </div>

      <div>
        <label className="label" htmlFor="s-role">
          Должность
        </label>
        <Select id="s-role" name="role" defaultValue={member?.role ?? "Администратор"}>
          {roles.map((r) => (
            <option key={r} value={r}>
              {r}
            </option>
          ))}
        </Select>
      </div>

      <Feedback error={error} saved={false} />

      <div className="flex justify-end gap-2 pt-1">
        <button type="button" className="btn-ghost" onClick={onClose}>
          Отмена
        </button>
        <button type="submit" className="btn-primary" disabled={pending}>
          {pending && <Loader2 className="h-4 w-4 animate-spin" />}
          Сохранить
        </button>
      </div>
    </form>
  );
}

export function StaffSection({ staff }: { staff: StaffView[] }) {
  const [editing, setEditing] = useState<StaffView | null | undefined>(undefined);
  const [toDelete, setToDelete] = useState<StaffView | null>(null);
  const del = useRun();

  return (
    <section className="max-w-3xl">
      <div className="mb-5 flex items-center justify-between gap-3">
        <p className="text-sm text-steel">Эти люди показываются на главной странице в блоке «Администрация».</p>
        <button type="button" className="btn-primary shrink-0" onClick={() => setEditing(null)}>
          <Plus className="h-4 w-4" /> Добавить
        </button>
      </div>

      {staff.length === 0 ? (
        <p className="card p-8 text-center text-steel">Пока никого нет. Добавьте первого администратора.</p>
      ) : (
        <ul className="space-y-3">
          {staff.map((m) => (
            <li key={m.id} className="card flex items-center gap-4 p-4">
              {m.avatarUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={m.avatarUrl} alt="" className="h-12 w-12 shrink-0 rounded-full object-cover" />
              ) : (
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand-100 text-lg font-extrabold text-brand-500">
                  {initials(m.nickname)}
                </span>
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate font-bold text-ink">{m.nickname}</p>
                <p className="text-sm text-steel">{m.role}</p>
              </div>
              <button type="button" className="btn-ghost !px-3 !py-2" onClick={() => setEditing(m)} aria-label={`Редактировать ${m.nickname}`}>
                <Pencil className="h-4 w-4" />
              </button>
              <button type="button" className="btn-danger !px-3 !py-2" onClick={() => setToDelete(m)} aria-label={`Удалить ${m.nickname}`}>
                <Trash2 className="h-4 w-4" />
              </button>
            </li>
          ))}
        </ul>
      )}

      <Feedback error={del.error} saved={false} />

      <Modal
        open={editing !== undefined}
        onClose={() => setEditing(undefined)}
        title={editing ? "Редактирование записи" : "Новый администратор"}
      >
        {editing !== undefined && (
          <StaffEditor key={editing?.id ?? "new"} member={editing} onClose={() => setEditing(undefined)} />
        )}
      </Modal>

      <ConfirmDialog
        open={!!toDelete}
        title="Удалить запись?"
        message={`«${toDelete?.nickname ?? ""}» будет удалён из списка администрации. Это действие нельзя отменить.`}
        pending={del.pending}
        onClose={() => setToDelete(null)}
        onConfirm={() => toDelete && del.run(() => deleteStaff(toDelete.id), () => setToDelete(null))}
      />
    </section>
  );
}

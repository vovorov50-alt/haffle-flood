"use client";

import Link from "next/link";
import { useState } from "react";
import { ExternalLink, LayoutDashboard, LogOut, ShieldCheck, SlidersHorizontal, Users } from "lucide-react";
import { logout } from "@/app/actions/auth";
import { HomeSection } from "@/components/admin/HomeSection";
import { CharactersSection } from "@/components/admin/CharactersSection";
import { StaffSection } from "@/components/admin/StaffSection";
import { SettingsSection } from "@/components/admin/SettingsSection";
import type { CharacterView, Settings, StaffView } from "@/lib/types";

const TABS = [
  { id: "home", label: "Главная", icon: LayoutDashboard },
  { id: "characters", label: "Персонажи", icon: Users },
  { id: "staff", label: "Администрация", icon: ShieldCheck },
  { id: "settings", label: "Настройки", icon: SlidersHorizontal },
] as const;
type TabId = (typeof TABS)[number]["id"];

export function AdminPanel({
  settings,
  characters,
  staff,
  email,
}: {
  settings: Settings;
  characters: CharacterView[];
  staff: StaffView[];
  email: string;
}) {
  const [tab, setTab] = useState<TabId>("home");

  return (
    <div className="mx-auto max-w-6xl px-4 py-8 sm:px-6 sm:py-10">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold tracking-tight text-ink sm:text-3xl">Панель управления</h1>
          <p className="mt-1 text-sm text-steel">Вы вошли как {email}</p>
        </div>
        <div className="flex items-center gap-2">
          <Link href="/" className="btn-ghost">
            <ExternalLink className="h-4 w-4" /> На сайт
          </Link>
          <form action={logout}>
            <button type="submit" className="btn-ghost">
              <LogOut className="h-4 w-4" /> Выйти
            </button>
          </form>
        </div>
      </div>

      <div role="tablist" className="mb-6 flex gap-1 overflow-x-auto rounded-2xl border border-brand-100 bg-white p-1.5 shadow-soft">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            role="tab"
            aria-selected={tab === id}
            onClick={() => setTab(id)}
            className={`flex shrink-0 items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition ${
              tab === id ? "bg-brand-500 text-white shadow-sm" : "text-steel hover:bg-brand-50 hover:text-ink"
            }`}
          >
            <Icon className="h-4 w-4" />
            {label}
          </button>
        ))}
      </div>

      {tab === "home" && <HomeSection settings={settings} />}
      {tab === "characters" && <CharactersSection characters={characters} />}
      {tab === "staff" && <StaffSection staff={staff} />}
      {tab === "settings" && <SettingsSection settings={settings} />}
    </div>
  );
}

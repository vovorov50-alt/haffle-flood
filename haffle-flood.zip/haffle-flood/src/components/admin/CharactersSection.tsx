"use client";

import { useMemo, useState } from "react";
import { Loader2, Plus, Search, Trash2 } from "lucide-react";
import { deleteCharacter, saveCharacter } from "@/app/admin/actions";
import { CharacterCard } from "@/components/CharacterCard";
import { Feedback } from "@/components/admin/Feedback";
import { ImagePicker } from "@/components/admin/ImagePicker";
import { useRun } from "@/components/admin/useRun";
import { ConfirmDialog, Modal } from "@/components/ui/Modal";
import { Select } from "@/components/ui/Select";
import {
  ELEMENTS,
  ELEMENT_LABELS,
  GENDERS,
  GENDER_LABELS,
  REGIONS,
  REGION_LABELS,
  STATUSES,
  STATUS_META,
} from "@/lib/constants";
import { normalize } from "@/lib/format";
import type { CharacterView } from "@/lib/types";

function CharacterEditor({ character, onClose }: { character: CharacterView | null; onClose: () => void }) {
  const { run, pending, error } = useRun();
  const del = useRun();
  const [confirm, setConfirm] = useState(false);

  return (
    <>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const fd = new FormData(e.currentTarget);
          run(() => saveCharacter(fd), onClose);
        }}
        className="space-y-4"
      >
        <input type="hidden" name="id" value={character?.id ?? ""} />

        <ImagePicker currentUrl={character?.imageUrl} />

        <div>
          <label className="label" htmlFor="c-name">
            Имя персонажа
          </label>
          <input id="c-name" name="name" defaultValue={character?.name ?? ""} maxLength={60} required className="input" />
        </div>

        <div>
          <label className="label" htmlFor="c-status">
            Статус
          </label>
          <Select id="c-status" name="status" defaultValue={character?.status ?? "free"}>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {STATUS_META[s].label}
              </option>
            ))}
          </Select>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="label" htmlFor="c-gender">
              Пол
            </label>
            <Select id="c-gender" name="gender" defaultValue={character?.gender ?? "female"}>
              {GENDERS.map((g) => (
                <option key={g} value={g}>
                  {GENDER_LABELS[g]}
                </option>
              ))}
            </Select>
          </div>
          <div>
            <label className="label" htmlFor="c-element">
              Стихия
            </label>
            <Select id="c-element" name="element" defaultValue={character?.element ?? "pyro"}>
              {ELEMENTS.map((el) => (
                <option key={el} value={el}>
                  {ELEMENT_LABELS[el]}
                </option>
              ))}
            </Select>
          </div>
        </div>

        <div>
          <label className="label" htmlFor="c-region">
            Регион
          </label>
          <Select id="c-region" name="region" defaultValue={character?.region ?? "other"}>
            {REGIONS.map((r) => (
              <option key={r} value={r}>
                {REGION_LABELS[r]}
              </option>
            ))}
          </Select>
        </div>

        <Feedback error={error ?? del.error} saved={false} />

        <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
          {character ? (
            <button type="button" className="btn-danger" onClick={() => setConfirm(true)} disabled={pending}>
              <Trash2 className="h-4 w-4" /> Удалить
            </button>
          ) : (
            <span />
          )}
          <div className="flex gap-2">
            <button type="button" className="btn-ghost" onClick={onClose}>
              Отмена
            </button>
            <button type="submit" className="btn-primary" disabled={pending}>
              {pending && <Loader2 className="h-4 w-4 animate-spin" />}
              Сохранить
            </button>
          </div>
        </div>
      </form>

      <ConfirmDialog
        open={confirm}
        title="Удалить персонажа?"
        message={`«${character?.name ?? ""}» будет удалён из каталога вместе с загруженной картинкой. Это действие нельзя отменить.`}
        pending={del.pending}
        onClose={() => setConfirm(false)}
        onConfirm={() =>
          character &&
          del.run(() => deleteCharacter(character.id), () => {
            setConfirm(false);
            onClose();
          })
        }
      />
    </>
  );
}

export function CharactersSection({ characters }: { characters: CharacterView[] }) {
  const [q, setQ] = useState("");
  const [status, setStatus] = useState("");
  // undefined — окно закрыто, null — создание, объект — редактирование
  const [editing, setEditing] = useState<CharacterView | null | undefined>(undefined);

  const list = useMemo(() => {
    const needle = normalize(q);
    return characters.filter((c) => (!needle || normalize(c.name).includes(needle)) && (!status || c.status === status));
  }, [characters, q, status]);

  return (
    <section>
      <div className="card mb-5 flex flex-wrap items-center gap-3 p-4">
        <div className="relative min-w-[14rem] flex-1">
          <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-steel" />
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Поиск персонажа по имени"
            aria-label="Поиск персонажа"
            className="input pl-10"
          />
        </div>
        <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Статус" className="w-full sm:w-44">
          <option value="">Любой статус</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_META[s].label}
            </option>
          ))}
        </Select>
        <button type="button" className="btn-primary" onClick={() => setEditing(null)}>
          <Plus className="h-4 w-4" /> Добавить персонажа
        </button>
      </div>

      <p className="mb-4 text-sm text-steel">
        Показано {list.length} из {characters.length}. Нажмите на карточку, чтобы изменить статус или картинку.
      </p>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-6">
        {list.map((c) => (
          <CharacterCard key={c.id} character={c} onClick={() => setEditing(c)} />
        ))}
      </div>

      {list.length === 0 && <p className="card mt-6 p-8 text-center text-steel">Ничего не найдено.</p>}

      <Modal
        open={editing !== undefined}
        onClose={() => setEditing(undefined)}
        title={editing ? `Редактирование: ${editing.name}` : "Новый персонаж"}
      >
        {editing !== undefined && (
          <CharacterEditor key={editing?.id ?? "new"} character={editing} onClose={() => setEditing(undefined)} />
        )}
      </Modal>
    </section>
  );
}

import { Check } from "lucide-react";

export function Feedback({ error, saved }: { error: string | null; saved: boolean }) {
  if (error)
    return (
      <p role="alert" className="rounded-xl bg-red-50 px-3.5 py-2.5 text-sm font-medium text-red-700">
        {error}
      </p>
    );
  if (saved)
    return (
      <p className="inline-flex items-center gap-1.5 text-sm font-semibold text-emerald-600">
        <Check className="h-4 w-4" /> Сохранено
      </p>
    );
  return null;
}

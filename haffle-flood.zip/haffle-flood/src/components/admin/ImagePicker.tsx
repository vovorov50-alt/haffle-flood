"use client";

import { useEffect, useRef, useState } from "react";
import { ImagePlus, RefreshCw, Trash2 } from "lucide-react";
import { IMAGE_MAX_MB } from "@/lib/constants";

/**
 * Выбор изображения с предпросмотром.
 * Поле файла уходит в форму под именем `name`; пометка удаления — в скрытое поле `removeName`.
 */
export function ImagePicker({
  currentUrl,
  name = "image",
  removeName = "remove_image",
  shape = "square",
  pngOnly = true,
  allowRemove = true,
  hint,
}: {
  currentUrl?: string | null;
  name?: string;
  removeName?: string;
  shape?: "square" | "circle" | "wide";
  pngOnly?: boolean;
  allowRemove?: boolean;
  hint?: string;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [removed, setRemoved] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => () => void (preview && URL.revokeObjectURL(preview)), [preview]);

  const shown = preview ?? (removed ? null : (currentUrl ?? null));
  const accept = pngOnly ? "image/png" : "image/png,image/jpeg,image/webp";

  function onChange(e: React.ChangeEvent<HTMLInputElement>) {
    const f = e.target.files?.[0];
    if (!f) return;
    const okType = pngOnly ? f.type === "image/png" : ["image/png", "image/jpeg", "image/webp"].includes(f.type);
    if (!okType) {
      setErr(pngOnly ? "Нужен файл PNG" : "Допустимы PNG, JPEG или WebP");
      e.target.value = "";
      return;
    }
    if (f.size > IMAGE_MAX_MB * 1024 * 1024) {
      setErr(`Файл больше ${IMAGE_MAX_MB} МБ`);
      e.target.value = "";
      return;
    }
    setErr(null);
    setRemoved(false);
    setPreview(URL.createObjectURL(f));
  }

  function clear() {
    if (inputRef.current) inputRef.current.value = "";
    setPreview(null);
    setRemoved(true);
    setErr(null);
  }

  const box =
    shape === "circle"
      ? "h-24 w-24 rounded-full"
      : shape === "wide"
        ? "h-40 w-40 rounded-2xl"
        : "h-32 w-32 rounded-2xl";

  return (
    <div className="flex items-center gap-4">
      <div
        className={`relative grid shrink-0 place-items-center overflow-hidden border border-dashed border-brand-200 bg-brand-50/60 ${box}`}
        style={shown ? { backgroundImage: "conic-gradient(#fff 25%, #f2f7ff 0 50%, #fff 0 75%, #f2f7ff 0)", backgroundSize: "16px 16px" } : undefined}
      >
        {shown ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={shown} alt="Предпросмотр" className={`h-full w-full ${shape === "circle" ? "object-cover" : "object-contain p-1"}`} />
        ) : (
          <ImagePlus className="h-6 w-6 text-brand-300" />
        )}
      </div>

      <div className="min-w-0 space-y-2">
        <input ref={inputRef} type="file" name={name} accept={accept} onChange={onChange} className="hidden" />
        <input type="hidden" name={removeName} value={removed && !preview ? "1" : ""} />
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn-ghost !px-3 !py-2" onClick={() => inputRef.current?.click()}>
            <RefreshCw className="h-4 w-4" />
            {shown ? "Заменить" : "Загрузить"}
          </button>
          {allowRemove && shown && (
            <button type="button" className="btn-danger !px-3 !py-2" onClick={clear}>
              <Trash2 className="h-4 w-4" />
              Убрать
            </button>
          )}
        </div>
        <p className="text-xs text-steel">{hint ?? `${pngOnly ? "PNG" : "PNG, JPEG, WebP"}, до ${IMAGE_MAX_MB} МБ`}</p>
        {preview && <p className="text-xs font-semibold text-brand-600">Новое изображение — нажмите «Сохранить».</p>}
        {err && <p className="text-xs font-semibold text-red-600">{err}</p>}
      </div>
    </div>
  );
}

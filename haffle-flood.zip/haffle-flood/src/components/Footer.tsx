export function Footer({ title }: { title: string }) {
  return (
    <footer className="mt-20 border-t border-brand-100 bg-mist/60">
      <div className="mx-auto flex max-w-6xl flex-col gap-3 px-4 py-8 text-sm text-steel sm:flex-row sm:items-center sm:justify-between sm:px-6">
        <div className="flex items-center gap-2.5">
          <span className="grid h-6 w-6 place-items-center rounded-lg bg-gradient-to-br from-brand-400 to-brand-600 text-[11px] font-extrabold text-white">
            H
          </span>
          <span className="font-extrabold tracking-tight text-ink">{title}</span>
          <span className="text-brand-200">•</span>
          <span>Telegram-флуд по Genshin Impact</span>
        </div>
        <p className="text-xs">Неофициальный фан-проект. Genshin Impact © HoYoverse.</p>
      </div>
    </footer>
  );
}

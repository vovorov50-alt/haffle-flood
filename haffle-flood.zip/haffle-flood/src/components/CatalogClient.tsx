"use client";

import { useMemo, useState } from "react";
import { RotateCcw, Search } from "lucide-react";
import { CharacterCard, StatusLegend } from "@/components/CharacterCard";
import { Select } from "@/components/ui/Select";
import {
  ELEMENTS,
  ELEMENT_LABELS,
  GENDERS,
  GENDER_LABELS,
  REGIONS,
  REGION_LABELS,
  STATUSES,
  STATUS_META,
} from "@/lib/constants";
import { normalize } from "@/lib/format";
import type { CharacterView } from "@/lib/types";

export function CatalogClient({ characters }: { characters: CharacterView[] }) {
  const [q, setQ] = useState("");
  const [gender, setGender] = useState("");
  const [element, setElement] = useState("");
  const [status, setStatus] = useState("");
  const [region, setRegion] = useState("");

  const filtered = useMemo(() => {
    const needle = normalize(q);
    return characters.filter(
      (c) =>
        (!needle || normalize(c.name).includes(needle)) &&
        (!gender || c.gender === gender) &&
        (!element || c.element === element) &&
        (!status || c.status === status) &&
        (!region || c.region === region),
    );
  }, [characters, q, gender, element, status, region]);

  const groups = useMemo(
    () =>
      REGIONS.map((r) => ({ region: r, items: filtered.filter((c) => c.region === r) })).filter(
        (g) => g.items.length > 0,
      ),
    [filtered],
  );

  const hasFilters = !!(q || gender || element || status || region);
  const reset = () => {
    setQ("");
    setGender("");
    setElement("");
    setStatus("");
    setRegion("");
  };

  return (
    <div>
      <div className="card p-4 sm:p-5">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-[1.4fr_repeat(4,1fr)]">
          <div className="relative sm:col-span-2 lg:col-span-1">
            <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-steel" />
            <input
              type="search"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Поиск по имени"
              aria-label="Поиск по имени"
              className="input pl-10"
            />
          </div>

          <Select value={gender} onChange={(e) => setGender(e.target.value)} aria-label="Пол">
            <option value="">Пол: любой</option>
            {GENDERS.map((g) => (
              <option key={g} value={g}>
                {GENDER_LABELS[g]}
              </option>
            ))}
          </Select>

          <Select value={element} onChange={(e) => setElement(e.target.value)} aria-label="Стихия">
            <option value="">Стихия: любая</option>
            {ELEMENTS.map((el) => (
              <option key={el} value={el}>
                {ELEMENT_LABELS[el]}
              </option>
            ))}
          </Select>

          <Select value={status} onChange={(e) => setStatus(e.target.value)} aria-label="Статус">
            <option value="">Статус: любой</option>
            {STATUSES.map((s) => (
              <option key={s} value={s}>
                {STATUS_META[s].label}
              </option>
            ))}
          </Select>

          <Select value={region} onChange={(e) => setRegion(e.target.value)} aria-label="Регион">
            <option value="">Регион: любой</option>
            {REGIONS.map((r) => (
              <option key={r} value={r}>
                {REGION_LABELS[r]}
              </option>
            ))}
          </Select>
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
          <StatusLegend />
          <div className="flex items-center gap-3">
            <span className="text-sm text-steel">
              Найдено: <b className="text-ink">{filtered.length}</b> из {characters.length}
            </span>
            <button type="button" onClick={reset} disabled={!hasFilters} className="btn-ghost !px-3 !py-2">
              <RotateCcw className="h-4 w-4" />
              Сбросить
            </button>
          </div>
        </div>
      </div>

      {groups.length === 0 ? (
        <div className="card mt-8 px-6 py-14 text-center">
          <p className="text-lg font-bold text-ink">Никого не нашли</p>
          <p className="mt-1 text-sm text-steel">Попробуйте изменить условия поиска или сбросить фильтры.</p>
          <button type="button" onClick={reset} className="btn-primary mt-5">
            Сбросить фильтры
          </button>
        </div>
      ) : (
        <div className="mt-10 space-y-12">
          {groups.map((g) => (
            <section key={g.region} aria-labelledby={`region-${g.region}`}>
              <div className="mb-4 flex items-baseline gap-3">
                <h2 id={`region-${g.region}`} className="text-xl font-extrabold tracking-tight text-ink">
                  {REGION_LABELS[g.region]}
                </h2>
                <span className="rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-bold text-brand-600">
                  {g.items.length}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                {g.items.map((c) => (
                  <CharacterCard key={c.id} character={c} />
                ))}
              </div>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

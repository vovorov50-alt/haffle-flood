import { STATUS_META } from "@/lib/constants";
import { initials } from "@/lib/format";
import type { CharacterView } from "@/lib/types";

export function StatusDot({ status, className = "" }: { status: CharacterView["status"]; className?: string }) {
  const meta = STATUS_META[status];
  return (
    <span
      title={meta.label}
      className={`inline-block h-3 w-3 rounded-full ring-4 ring-white/90 ${meta.dot} ${className}`}
    >
      <span className="sr-only">{meta.label}</span>
    </span>
  );
}

/** Квадратная карточка персонажа: картинка (или заглушка), имя, индикатор статуса. */
export function CharacterCard({
  character,
  onClick,
}: {
  character: CharacterView;
  onClick?: () => void;
}) {
  const body = (
    <>
      {character.imageUrl ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={character.imageUrl}
          alt={character.name}
          loading="lazy"
          decoding="async"
          className="absolute inset-0 h-full w-full object-contain p-3 pb-11 transition duration-300 group-hover:scale-[1.04]"
        />
      ) : (
        <div className="absolute inset-0 grid place-items-center pb-8">
          <span className="grid h-16 w-16 place-items-center rounded-full bg-brand-100/80 text-2xl font-extrabold text-brand-400 sm:h-20 sm:w-20 sm:text-3xl">
            {initials(character.name)}
          </span>
        </div>
      )}

      <StatusDot status={character.status} className="absolute right-2.5 top-2.5" />

      <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-white via-white/95 to-transparent px-2.5 pb-2.5 pt-7">
        <p className="truncate text-center text-[13px] font-bold text-ink sm:text-sm">{character.name}</p>
      </div>
    </>
  );

  const cls =
    "group relative block aspect-square w-full overflow-hidden rounded-2xl border border-brand-100 bg-gradient-to-b from-white to-brand-50 text-left shadow-soft transition duration-300 hover:-translate-y-1 hover:border-brand-200 hover:shadow-lift";

  return onClick ? (
    <button type="button" onClick={onClick} className={cls} aria-label={`Редактировать: ${character.name}`}>
      {body}
    </button>
  ) : (
    <div className={cls}>{body}</div>
  );
}

export function StatusLegend() {
  return (
    <ul className="flex flex-wrap items-center gap-x-5 gap-y-2 text-sm text-steel">
      {(Object.keys(STATUS_META) as (keyof typeof STATUS_META)[]).map((k) => (
        <li key={k} className="flex items-center gap-2">
          <span className={`h-2.5 w-2.5 rounded-full ${STATUS_META[k].dot}`} />
          {STATUS_META[k].label}
        </li>
      ))}
    </ul>
  );
}

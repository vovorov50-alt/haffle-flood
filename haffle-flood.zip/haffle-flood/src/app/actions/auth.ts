"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export type LoginState = { error?: string } | undefined;

/** Серверный вход: пароль проверяет Supabase Auth (хеш bcrypt), сессия живёт в httpOnly-cookie. */
export async function login(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const email = String(formData.get("email") ?? "").trim();
  const password = String(formData.get("password") ?? "");
  if (!email || !password) return { error: "Введите логин и пароль" };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error || !data.user) return { error: "Неверный логин или пароль" };

  // Вошедший пользователь обязан быть в списке администраторов сайта
  const { data: row } = await supabase
    .from("site_admins")
    .select("user_id")
    .eq("user_id", data.user.id)
    .maybeSingle();

  if (!row) {
    await supabase.auth.signOut();
    return { error: "У этой учётной записи нет прав администратора" };
  }

  redirect("/admin");
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}

import Link from "next/link";
import { ArrowRight, Send, Users } from "lucide-react";
import { getCharacters, getSettings, getStaff } from "@/lib/data";
import { mediaUrl } from "@/lib/media";
import { plural, initials } from "@/lib/format";
import { STATUSES, STATUS_META } from "@/lib/constants";

export const dynamic = "force-dynamic";

function HeroArt({ url, side }: { url: string | null; side: "left" | "right" }) {
  return (
    <div className={`relative h-44 sm:h-56 md:h-[26rem] ${side === "left" ? "order-2 md:order-1" : "order-3"}`}>
      {url ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={url}
          alt=""
          decoding="async"
          className={`animate-float h-full w-full object-contain ${side === "left" ? "object-right-bottom" : "object-left-bottom"}`}
          style={{ animationDelay: side === "left" ? "0s" : "-3.5s" }}
        />
      ) : (
        <div
          aria-hidden
          className="absolute inset-x-6 bottom-0 top-8 rounded-[2.5rem] bg-gradient-to-b from-brand-100/70 to-transparent md:inset-x-4"
        />
      )}
    </div>
  );
}

export default async function HomePage() {
  const [settings, staff, characters] = await Promise.all([getSettings(), getStaff(), getCharacters()]);

  const words = settings.site_title.trim().split(/\s+/);
  const last = words.length > 1 ? words.pop() : null;
  const first = words.join(" ");

  const counts = Object.fromEntries(STATUSES.map((s) => [s, characters.filter((c) => c.status === s).length]));

  return (
    <div className="mx-auto max-w-6xl px-4 sm:px-6">
      {/* HERO */}
      <section className="grid grid-cols-2 items-end gap-x-3 pt-8 md:grid-cols-[1fr_auto_1fr] md:gap-x-6 md:pt-12">
        <HeroArt url={mediaUrl(settings.hero_left_path)} side="left" />

        <div className="order-1 col-span-2 animate-fade-up pb-4 text-center md:order-2 md:col-span-1 md:pb-16">
          <span className="inline-flex items-center gap-2 rounded-full border border-brand-100 bg-white px-3.5 py-1.5 text-xs font-bold text-brand-600 shadow-soft">
            <span className="h-1.5 w-1.5 rounded-full bg-brand-500" />
            Telegram-флуд · Genshin Impact
          </span>
          <h1 className="mt-5 text-[2.6rem] font-extrabold uppercase leading-[0.95] tracking-tight text-ink sm:text-6xl lg:text-7xl">
            {first}
            {last && (
              <>
                <br />
                <span className="bg-gradient-to-r from-brand-500 to-brand-400 bg-clip-text text-transparent">{last}</span>
              </>
            )}
          </h1>
          <p className="mx-auto mt-5 max-w-md text-base leading-relaxed text-steel sm:text-lg">{settings.tagline}</p>
          <div className="mt-7 flex flex-wrap items-center justify-center gap-3">
            <Link href="/characters" className="btn-primary !px-5 !py-3">
              Просмотреть персонажей <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>

        <HeroArt url={mediaUrl(settings.hero_right_path)} side="right" />
      </section>

      {/* INFO BLOCKS */}
      <section className="mt-16 grid gap-5 lg:grid-cols-5">
        {/* Участники */}
        <div className="card animate-fade-up relative overflow-hidden p-7 lg:col-span-2">
          <div className="absolute -right-10 -top-10 h-40 w-40 rounded-full bg-brand-100/70 blur-2xl" aria-hidden />
          <div className="relative">
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-brand-50 text-brand-500">
              <Users className="h-5 w-5" />
            </span>
            <p className="mt-6 text-sm font-semibold text-steel">Сейчас в флуде</p>
            <p className="mt-1 flex items-baseline gap-2.5">
              <span className="text-6xl font-extrabold tracking-tight text-ink">
                {settings.members_count.toLocaleString("ru-RU")}
              </span>
              <span className="text-lg font-bold text-brand-500">
                {plural(settings.members_count, ["участник", "участника", "участников"])}
              </span>
            </p>
          </div>
        </div>

        {/* Администрация */}
        <div className="card animate-fade-up p-7 lg:col-span-3" style={{ animationDelay: "80ms" }}>
          <h2 className="text-lg font-extrabold tracking-tight text-ink">Администрация</h2>
          {staff.length === 0 ? (
            <p className="mt-4 text-sm text-steel">Список администрации скоро появится.</p>
          ) : (
            <ul className="mt-5 grid gap-3 sm:grid-cols-2">
              {staff.map((m) => (
                <li
                  key={m.id}
                  className="flex items-center gap-3.5 rounded-2xl border border-brand-100/80 bg-mist/60 p-3 transition hover:border-brand-200 hover:bg-white hover:shadow-soft"
                >
                  {m.avatarUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={m.avatarUrl} alt="" loading="lazy" className="h-12 w-12 shrink-0 rounded-full border border-white object-cover shadow-sm" />
                  ) : (
                    <span className="grid h-12 w-12 shrink-0 place-items-center rounded-full bg-brand-100 text-lg font-extrabold text-brand-500">
                      {initials(m.nickname)}
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-[15px] font-bold text-ink">{m.nickname}</p>
                    <p
                      className={`mt-0.5 inline-block rounded-full px-2.5 py-0.5 text-xs font-bold ${
                        m.role === "Владелец" ? "bg-brand-500 text-white" : "bg-brand-50 text-brand-600"
                      }`}
                    >
                      {m.role}
                    </p>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Каталог */}
        <div
          className="card animate-fade-up flex flex-col justify-between gap-6 p-7 sm:flex-row sm:items-center lg:col-span-5"
          style={{ animationDelay: "140ms" }}
        >
          <div className="max-w-xl">
            <h2 className="text-lg font-extrabold tracking-tight text-ink">Каталог персонажей</h2>
            <p className="mt-2 leading-relaxed text-steel">{settings.catalog_blurb}</p>
            <ul className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-steel">
              {STATUSES.map((s) => (
                <li key={s} className="flex items-center gap-2">
                  <span className={`h-2.5 w-2.5 rounded-full ${STATUS_META[s].dot}`} />
                  {STATUS_META[s].label}: <b className="text-ink">{counts[s]}</b>
                </li>
              ))}
            </ul>
          </div>
          <Link href="/characters" className="btn-primary shrink-0 !px-5 !py-3">
            Просмотреть персонажей <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* ВСТУПЛЕНИЕ */}
      <section className="relative mt-16 overflow-hidden rounded-[2rem] bg-ink px-6 py-14 text-center sm:px-12 sm:py-16">
        <div className="absolute -left-20 -top-24 h-72 w-72 rounded-full bg-brand-500/30 blur-3xl" aria-hidden />
        <div className="absolute -bottom-28 -right-16 h-80 w-80 rounded-full bg-brand-400/20 blur-3xl" aria-hidden />
        <div className="relative">
          <h2 className="text-2xl font-extrabold tracking-tight text-white sm:text-4xl">Готов присоединиться?</h2>
          <p className="mx-auto mt-3 max-w-md text-brand-200">
            Заходи в Telegram, выбирай свободного персонажа и знакомься с остальными.
          </p>
          {settings.telegram_url ? (
            <a
              href={settings.telegram_url}
              target="_blank"
              rel="noopener noreferrer"
              className="mt-8 inline-flex items-center gap-2.5 rounded-2xl bg-white px-7 py-4 text-base font-extrabold text-ink shadow-lift transition hover:-translate-y-0.5 hover:bg-brand-50"
            >
              <Send className="h-5 w-5 text-brand-500" />
              Вступить в {settings.site_title}
            </a>
          ) : (
            <span className="mt-8 inline-flex rounded-2xl bg-white/10 px-7 py-4 text-base font-bold text-brand-200">
              Ссылка на группу скоро появится
            </span>
          )}
        </div>
      </section>
    </div>
  );
}

import type { Metadata } from "next";
import { CatalogClient } from "@/components/CatalogClient";
import { getCharacters, getSettings } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Каталог персонажей" };

export default async function CharactersPage() {
  const [characters, settings] = await Promise.all([getCharacters(), getSettings()]);

  return (
    <div className="mx-auto max-w-6xl px-4 pb-4 pt-10 sm:px-6 sm:pt-14">
      <header className="mb-8 max-w-2xl animate-fade-up">
        <p className="text-sm font-bold uppercase tracking-widest text-brand-500">{settings.site_title}</p>
        <h1 className="mt-2 text-3xl font-extrabold tracking-tight text-ink sm:text-4xl">Каталог персонажей</h1>
        <p className="mt-3 text-steel">{settings.catalog_blurb}</p>
      </header>
      <CatalogClient characters={characters} />
    </div>
  );
}

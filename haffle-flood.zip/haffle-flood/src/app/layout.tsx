import type { Metadata, Viewport } from "next";
import { Manrope } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/Navbar";
import { Footer } from "@/components/Footer";
import { getSettings } from "@/lib/data";
import { getAdminContext } from "@/lib/auth";

const font = Manrope({ subsets: ["latin", "cyrillic"], variable: "--font-sans", display: "swap" });

export const metadata: Metadata = {
  title: { default: "Haffle flood", template: "%s · Haffle flood" },
  description: "Telegram-флуд по Genshin Impact: участники, администрация и каталог персонажей.",
};

export const viewport: Viewport = { themeColor: "#ffffff", width: "device-width", initialScale: 1 };

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const [settings, admin] = await Promise.all([getSettings(), getAdminContext()]);

  return (
    <html lang="ru" className={font.variable}>
      <body className="flex min-h-screen flex-col">
        <Navbar title={settings.site_title} isAdmin={!!admin} />
        <main className="flex-1">{children}</main>
        <Footer title={settings.site_title} />
      </body>
    </html>
  );
}

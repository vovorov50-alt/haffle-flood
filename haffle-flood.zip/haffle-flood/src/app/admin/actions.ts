"use server";

import { revalidatePath } from "next/cache";
import { getAdminContext } from "@/lib/auth";
import { isTelegramUrl } from "@/lib/validate";
import { pickFile, removeImage, uploadImage } from "@/lib/upload";
import { ELEMENTS, GENDERS, REGIONS, STATUSES } from "@/lib/constants";
import type { ActionResult, Element, Gender, Region, Status } from "@/lib/types";

const fail = (error: string): ActionResult => ({ ok: false, error });
const OK: ActionResult = { ok: true };
const NO_ACCESS = "Нет доступа. Войдите заново.";

const text = (fd: FormData, key: string) => String(fd.get(key) ?? "").trim();

function refresh() {
  revalidatePath("/", "layout");
}

/* ------------------------------------------------------------------ */
/* Настройки сайта (главная + настройки)                               */
/* ------------------------------------------------------------------ */
export async function updateSettings(formData: FormData): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const patch: Record<string, string | number> = {};

  if (formData.has("site_title")) {
    const v = text(formData, "site_title");
    if (!v || v.length > 60) return fail("Название: от 1 до 60 символов");
    patch.site_title = v;
  }
  if (formData.has("tagline")) {
    const v = text(formData, "tagline");
    if (v.length > 300) return fail("Описание на главной: не больше 300 символов");
    patch.tagline = v;
  }
  if (formData.has("catalog_blurb")) {
    const v = text(formData, "catalog_blurb");
    if (v.length > 400) return fail("Описание каталога: не больше 400 символов");
    patch.catalog_blurb = v;
  }
  if (formData.has("members_count")) {
    const n = Number(text(formData, "members_count"));
    if (!Number.isInteger(n) || n < 0 || n > 10_000_000) return fail("Количество участников: целое число от 0");
    patch.members_count = n;
  }
  if (formData.has("telegram_url")) {
    const v = text(formData, "telegram_url");
    if (v && !isTelegramUrl(v)) return fail("Нужна ссылка вида https://t.me/+xxxxxxxx");
    patch.telegram_url = v;
  }

  if (Object.keys(patch).length === 0) return OK;

  const { data, error } = await ctx.supabase
    .from("site_settings")
    .update({ ...patch, updated_at: new Date().toISOString() })
    .eq("id", 1)
    .select("id");
  if (error) return fail(error.message);
  if (!data?.length) return fail("Не удалось сохранить (нет прав)");

  refresh();
  return OK;
}

/* ------------------------------------------------------------------ */
/* Декоративные PNG на главной                                         */
/* ------------------------------------------------------------------ */
const HERO_COLUMN = { left: "hero_left_path", right: "hero_right_path" } as const;

export async function setHeroImage(formData: FormData): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const side = text(formData, "side");
  if (side !== "left" && side !== "right") return fail("Некорректная сторона");
  const column = HERO_COLUMN[side];

  const file = pickFile(formData, "image");
  if (!file) return fail("Выберите PNG-файл");

  const { data: current } = await ctx.supabase.from("site_settings").select(column).eq("id", 1).maybeSingle();
  const oldPath = (current as Record<string, string | null> | null)?.[column] ?? null;

  const up = await uploadImage(ctx.supabase, file, "hero", { pngOnly: true });
  if ("error" in up) return fail(up.error);

  const { data, error } = await ctx.supabase
    .from("site_settings")
    .update({ [column]: up.path, updated_at: new Date().toISOString() })
    .eq("id", 1)
    .select("id");
  if (error || !data?.length) {
    await removeImage(ctx.supabase, up.path);
    return fail(error?.message ?? "Не удалось сохранить (нет прав)");
  }

  await removeImage(ctx.supabase, oldPath);
  refresh();
  return OK;
}

export async function removeHeroImage(side: "left" | "right"): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);
  if (side !== "left" && side !== "right") return fail("Некорректная сторона");
  const column = HERO_COLUMN[side];

  const { data: current } = await ctx.supabase.from("site_settings").select(column).eq("id", 1).maybeSingle();
  const oldPath = (current as Record<string, string | null> | null)?.[column] ?? null;

  const { data, error } = await ctx.supabase
    .from("site_settings")
    .update({ [column]: null, updated_at: new Date().toISOString() })
    .eq("id", 1)
    .select("id");
  if (error) return fail(error.message);
  if (!data?.length) return fail("Не удалось сохранить (нет прав)");

  await removeImage(ctx.supabase, oldPath);
  refresh();
  return OK;
}

/* ------------------------------------------------------------------ */
/* Персонажи                                                           */
/* ------------------------------------------------------------------ */
export async function saveCharacter(formData: FormData): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const id = text(formData, "id");
  const name = text(formData, "name");
  const status = text(formData, "status") as Status;
  const gender = text(formData, "gender") as Gender;
  const element = text(formData, "element") as Element;
  const region = text(formData, "region") as Region;
  const wantsRemove = text(formData, "remove_image") === "1";
  const file = pickFile(formData, "image");

  if (!name || name.length > 60) return fail("Имя: от 1 до 60 символов");
  if (!STATUSES.includes(status)) return fail("Некорректный статус");
  if (!GENDERS.includes(gender)) return fail("Некорректный пол");
  if (!ELEMENTS.includes(element)) return fail("Некорректная стихия");
  if (!REGIONS.includes(region)) return fail("Некорректный регион");

  // загрузка нового PNG (если выбран)
  let newPath: string | null = null;
  if (file) {
    const up = await uploadImage(ctx.supabase, file, "characters", { pngOnly: true });
    if ("error" in up) return fail(up.error);
    newPath = up.path;
  }

  if (id) {
    const { data: existing } = await ctx.supabase.from("characters").select("image_path").eq("id", id).maybeSingle();
    if (!existing) {
      await removeImage(ctx.supabase, newPath);
      return fail("Персонаж не найден");
    }
    const oldPath: string | null = existing.image_path;

    const update: Record<string, unknown> = { name, status, gender, element, region };
    if (newPath) update.image_path = newPath;
    else if (wantsRemove) update.image_path = null;

    const { data, error } = await ctx.supabase.from("characters").update(update).eq("id", id).select("id");
    if (error || !data?.length) {
      await removeImage(ctx.supabase, newPath);
      return fail(error?.message ?? "Не удалось сохранить (нет прав)");
    }
    if (newPath || wantsRemove) await removeImage(ctx.supabase, oldPath);
  } else {
    const { data: last } = await ctx.supabase
      .from("characters")
      .select("sort_order")
      .order("sort_order", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { error } = await ctx.supabase.from("characters").insert({
      slug: `custom-${crypto.randomUUID().slice(0, 8)}`,
      name,
      status,
      gender,
      element,
      region,
      image_path: newPath,
      sort_order: (last?.sort_order ?? 0) + 1,
    });
    if (error) {
      await removeImage(ctx.supabase, newPath);
      return fail(error.message);
    }
  }

  refresh();
  return OK;
}

export async function deleteCharacter(id: string): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const { data: existing } = await ctx.supabase.from("characters").select("image_path").eq("id", id).maybeSingle();
  const { data, error } = await ctx.supabase.from("characters").delete().eq("id", id).select("id");
  if (error) return fail(error.message);
  if (!data?.length) return fail("Не удалось удалить (нет прав)");

  await removeImage(ctx.supabase, existing?.image_path);
  refresh();
  return OK;
}

/* ------------------------------------------------------------------ */
/* Администрация                                                       */
/* ------------------------------------------------------------------ */
export async function saveStaff(formData: FormData): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const id = text(formData, "id");
  const nickname = text(formData, "nickname");
  const role = text(formData, "role");
  const wantsRemove = text(formData, "remove_image") === "1";
  const file = pickFile(formData, "image");

  if (!nickname || nickname.length > 40) return fail("Никнейм: от 1 до 40 символов");
  if (!role || role.length > 40) return fail("Выберите должность");

  let newPath: string | null = null;
  if (file) {
    const up = await uploadImage(ctx.supabase, file, "avatars", { pngOnly: false });
    if ("error" in up) return fail(up.error);
    newPath = up.path;
  }

  if (id) {
    const { data: existing } = await ctx.supabase.from("staff").select("avatar_path").eq("id", id).maybeSingle();
    if (!existing) {
      await removeImage(ctx.supabase, newPath);
      return fail("Запись не найдена");
    }
    const update: Record<string, unknown> = { nickname, role };
    if (newPath) update.avatar_path = newPath;
    else if (wantsRemove) update.avatar_path = null;

    const { data, error } = await ctx.supabase.from("staff").update(update).eq("id", id).select("id");
    if (error || !data?.length) {
      await removeImage(ctx.supabase, newPath);
      return fail(error?.message ?? "Не удалось сохранить (нет прав)");
    }
    if (newPath || wantsRemove) await removeImage(ctx.supabase, existing.avatar_path);
  } else {
    const { data: last } = await ctx.supabase
      .from("staff")
      .select("sort_order")
      .order("sort_order", { ascending: false })
      .limit(1)
      .maybeSingle();

    const { error } = await ctx.supabase
      .from("staff")
      .insert({ nickname, role, avatar_path: newPath, sort_order: (last?.sort_order ?? 0) + 1 });
    if (error) {
      await removeImage(ctx.supabase, newPath);
      return fail(error.message);
    }
  }

  refresh();
  return OK;
}

export async function deleteStaff(id: string): Promise<ActionResult> {
  const ctx = await getAdminContext();
  if (!ctx) return fail(NO_ACCESS);

  const { data: existing } = await ctx.supabase.from("staff").select("avatar_path").eq("id", id).maybeSingle();
  const { data, error } = await ctx.supabase.from("staff").delete().eq("id", id).select("id");
  if (error) return fail(error.message);
  if (!data?.length) return fail("Не удалось удалить (нет прав)");

  await removeImage(ctx.supabase, existing?.avatar_path);
  refresh();
  return OK;
}

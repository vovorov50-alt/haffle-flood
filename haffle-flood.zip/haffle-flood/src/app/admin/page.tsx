import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { getAdminContext } from "@/lib/auth";
import { getCharacters, getSettings, getStaff } from "@/lib/data";

export const dynamic = "force-dynamic";
export const metadata: Metadata = { title: "Панель управления", robots: { index: false, follow: false } };

export default async function AdminPage() {
  // Серверная проверка прав: без сессии администратора страница не отдаётся
  const ctx = await getAdminContext();
  if (!ctx) redirect("/");

  const [settings, characters, staff] = await Promise.all([getSettings(), getCharacters(), getStaff()]);

  return (
    <AdminPanel settings={settings} characters={characters} staff={staff} email={ctx.user.email ?? ""} />
  );
}

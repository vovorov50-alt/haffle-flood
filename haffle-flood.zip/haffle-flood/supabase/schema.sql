-- =====================================================================
-- HAFFLE FLOOD — схема базы данных Supabase
-- Выполните весь файл целиком: Supabase → SQL Editor → New query → Run.
-- Скрипт можно запускать повторно (он идемпотентный).
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. Кто является администратором сайта
-- ---------------------------------------------------------------------
create table if not exists public.site_admins (
  user_id    uuid primary key references auth.users (id) on delete cascade,
  created_at timestamptz not null default now()
);

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (select 1 from public.site_admins where user_id = auth.uid());
$$;

-- ---------------------------------------------------------------------
-- 2. Настройки сайта (ровно одна строка)
-- ---------------------------------------------------------------------
create table if not exists public.site_settings (
  id              int primary key default 1 check (id = 1),
  site_title      text not null default 'Haffle flood',
  tagline         text not null default 'Telegram-флуд по Genshin Impact. Выбирай персонажа, знакомься и заходи в уютную компанию.',
  members_count   int  not null default 0 check (members_count >= 0),
  telegram_url    text not null default '',
  catalog_blurb   text not null default 'Все персонажи Genshin Impact в одном месте: смотри, кто свободен, кто занят, а кого можно забронировать.',
  hero_left_path  text,
  hero_right_path text,
  updated_at      timestamptz not null default now()
);

insert into public.site_settings (id) values (1) on conflict (id) do nothing;

-- ---------------------------------------------------------------------
-- 3. Персонажи
-- ---------------------------------------------------------------------
create table if not exists public.characters (
  id         uuid primary key default gen_random_uuid(),
  slug       text not null unique,
  name       text not null,
  gender     text not null check (gender in ('female', 'male')),
  element    text not null check (element in ('pyro','hydro','anemo','electro','dendro','cryo','geo')),
  region     text not null check (region in ('mondstadt','liyue','inazuma','sumeru','fontaine','natlan','nodkrai','snezhnaya','other')),
  status     text not null default 'free' check (status in ('free', 'busy', 'reserved')),
  image_path text,
  sort_order int  not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists characters_region_sort_idx on public.characters (region, sort_order);

-- ---------------------------------------------------------------------
-- 4. Администрация флуда (для отображения на главной)
-- ---------------------------------------------------------------------
create table if not exists public.staff (
  id          uuid primary key default gen_random_uuid(),
  nickname    text not null,
  role        text not null,
  avatar_path text,
  sort_order  int  not null default 0,
  created_at  timestamptz not null default now()
);

-- ---------------------------------------------------------------------
-- 5. Права доступа и RLS
--    Читать данные может любой посетитель, менять — только админ.
-- ---------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant execute on function public.is_admin() to anon, authenticated;

grant select on public.site_settings, public.characters, public.staff to anon, authenticated;
grant update on public.site_settings to authenticated;
grant insert, update, delete on public.characters, public.staff to authenticated;
grant select on public.site_admins to authenticated;

alter table public.site_admins   enable row level security;
alter table public.site_settings enable row level security;
alter table public.characters    enable row level security;
alter table public.staff         enable row level security;

drop policy if exists "admins read self"      on public.site_admins;
drop policy if exists "settings public read"  on public.site_settings;
drop policy if exists "settings admin update" on public.site_settings;
drop policy if exists "characters public read"  on public.characters;
drop policy if exists "characters admin insert" on public.characters;
drop policy if exists "characters admin update" on public.characters;
drop policy if exists "characters admin delete" on public.characters;
drop policy if exists "staff public read"  on public.staff;
drop policy if exists "staff admin insert" on public.staff;
drop policy if exists "staff admin update" on public.staff;
drop policy if exists "staff admin delete" on public.staff;

-- site_admins: пользователь видит только свою строку; изменять таблицу через API нельзя
create policy "admins read self" on public.site_admins
  for select to authenticated using (user_id = auth.uid());

create policy "settings public read" on public.site_settings
  for select using (true);
create policy "settings admin update" on public.site_settings
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

create policy "characters public read" on public.characters
  for select using (true);
create policy "characters admin insert" on public.characters
  for insert to authenticated with check (public.is_admin());
create policy "characters admin update" on public.characters
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "characters admin delete" on public.characters
  for delete to authenticated using (public.is_admin());

create policy "staff public read" on public.staff
  for select using (true);
create policy "staff admin insert" on public.staff
  for insert to authenticated with check (public.is_admin());
create policy "staff admin update" on public.staff
  for update to authenticated using (public.is_admin()) with check (public.is_admin());
create policy "staff admin delete" on public.staff
  for delete to authenticated using (public.is_admin());

-- ---------------------------------------------------------------------
-- 6. Хранилище изображений (bucket "media", публичное чтение)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('media', 'media', true, 3145728, array['image/png', 'image/jpeg', 'image/webp'])
on conflict (id) do update
  set public = true,
      file_size_limit = excluded.file_size_limit,
      allowed_mime_types = excluded.allowed_mime_types;

drop policy if exists "media public read"  on storage.objects;
drop policy if exists "media admin insert" on storage.objects;
drop policy if exists "media admin update" on storage.objects;
drop policy if exists "media admin delete" on storage.objects;

create policy "media public read" on storage.objects
  for select using (bucket_id = 'media');
create policy "media admin insert" on storage.objects
  for insert to authenticated with check (bucket_id = 'media' and public.is_admin());
create policy "media admin update" on storage.objects
  for update to authenticated using (bucket_id = 'media' and public.is_admin());
create policy "media admin delete" on storage.objects
  for delete to authenticated using (bucket_id = 'media' and public.is_admin());
